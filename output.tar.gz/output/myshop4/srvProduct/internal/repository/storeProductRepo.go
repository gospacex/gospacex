package repository

import (
	"context"
	"fmt"
	"time"

	"myshop4/pkg/database"
	"github.com/gospacex/logger"
	"myshop4/srvProduct/internal/model"
	pb "myshop4/common/kitexGen/storeProduct"

	"gorm.io/gorm"
)

type StoreProductRepo struct { db *gorm.DB }

func NewStoreProductRepo(db *gorm.DB) *StoreProductRepo {
	if db == nil {
		db, _ = database.NewDB(nil)
	}
	logger.Business.Infow("StoreProductRepo initialized")
	return &StoreProductRepo{db: db}
}

func (r *StoreProductRepo) Create(ctx context.Context, m *model.StoreProduct) error {
	start := time.Now()
	logger.Business.Infow("create product", "model", m)

	if err := r.db.WithContext(ctx).Create(m).Error; err != nil {
		logger.Business.Errorw("create product failed", "error", err.Error())
		return err
	}

	logger.Business.Infow("create product success", "id", m.Id, "duration", time.Since(start).String())
	return nil
}

func (r *StoreProductRepo) GetByID(ctx context.Context, id int64) (*model.StoreProduct, error) {
	start := time.Now()
	logger.Business.Infow("get product by id", "id", id)

	var m model.StoreProduct
	if err := r.db.WithContext(ctx).Where("id = ? AND is_del = 0", id).First(&m).Error; err != nil {
		logger.Business.Errorw("get product failed", "error", err.Error())
		return nil, err
	}

	logger.Business.Infow("get product success", "id", id, "duration", time.Since(start).String())
	return &m, nil
}

func (r *StoreProductRepo) List(ctx context.Context) ([]*model.StoreProduct, error) {
	start := time.Now()
	logger.Business.Infow("list product")

	var list []*model.StoreProduct
	err := r.db.WithContext(ctx).Where("is_del = 0").Find(&list).Error
	if err != nil {
		logger.Business.Errorw("list product failed", "error", err.Error())
		return nil, err
	}

	logger.Business.Infow("list product success", "count", len(list), "duration", time.Since(start).String())
	return list, nil
}

// ListWithFilter 支持分页和过滤条件的列表查询
func (r *StoreProductRepo) ListWithFilter(ctx context.Context, req *pb.ListStoreProductReq) ([]*model.StoreProduct, error) {
	start := time.Now()
	logger.Business.Infow("list product with filter", "page", req.Page, "pageSize", req.PageSize)

	query := r.db.WithContext(ctx)
	query = query.Where("is_del = 0")

	// 分页处理
	page := req.Page
	pageSize := req.PageSize
	if page <= 0 {
		page = 1
	}
	if pageSize <= 0 {
		pageSize = 20
	}
	if pageSize > 100 {
		pageSize = 100
	}
	offset := (page - 1) * pageSize

	var list []*model.StoreProduct
	err := query.Offset(int(offset)).Limit(int(pageSize)).Find(&list).Error
	if err != nil {
		logger.Business.Errorw("list product with filter failed", "error", err.Error())
		return nil, err
	}

	logger.Business.Infow("list product with filter success", "count", len(list), "page", page, "pageSize", pageSize, "duration", time.Since(start).String())
	return list, nil
}

func (r *StoreProductRepo) Update(ctx context.Context, m *model.StoreProduct) error {
	start := time.Now()
	logger.Business.Infow("update product", "id", m.Id)

	if err := r.db.WithContext(ctx).Save(m).Error; err != nil {
		logger.Business.Errorw("update product failed", "error", err.Error())
		return err
	}

	logger.Business.Infow("update product success", "id", m.Id, "duration", time.Since(start).String())
	return nil
}

func (r *StoreProductRepo) Delete(ctx context.Context, id int64) error {
	start := time.Now()
	logger.Business.Infow("delete product", "id", id)
	err := r.db.WithContext(ctx).Model(&model.StoreProduct{}).Where("id = ?", id).Update("is_del", 1).Error
	if err != nil {
		logger.Business.Errorw("delete product failed", "error", err.Error())
		return err
	}

	logger.Business.Infow("delete product success", "id", id, "duration", time.Since(start).String())
	return nil
}

// FindStoreProduct2StoreProductAttr 联表查询
func (r *StoreProductRepo) FindStoreProduct2StoreProductAttr(ctx context.Context, id int64) (*model.JoinStoreProductStoreProductAttr, error) {
	var result model.JoinStoreProductStoreProductAttr
	err := r.db.WithContext(ctx).
		Table("`eb_store_product` AS store_product").
		Select("`store_product`.`id`, `store_product`.`mer_id`, `store_product`.`image`, `store_product`.`recommend_image`, `store_product`.`slider_image`, `store_product`.`store_name`, `store_product`.`store_info`, `store_product`.`keyword`, `store_product`.`bar_code`, `store_product`.`cate_id`, `store_product`.`price`, `store_product`.`vip_price`, `store_product`.`ot_price`, `store_product`.`postage`, `store_product`.`unit_name`, `store_product`.`sort`, `store_product`.`sales`, `store_product`.`stock`, `store_product`.`is_show`, `store_product`.`is_hot`, `store_product`.`is_benefit`, `store_product`.`is_best`, `store_product`.`is_new`, `store_product`.`is_virtual`, `store_product`.`virtual_type`, `store_product`.`add_time`, `store_product`.`is_postage`, `store_product`.`is_del`, `store_product`.`mer_use`, `store_product`.`give_integral`, `store_product`.`cost`, `store_product`.`is_seckill`, `store_product`.`is_bargain`, `store_product`.`is_good`, `store_product`.`is_sub`, `store_product`.`is_vip`, `store_product`.`ficti`, `store_product`.`browse`, `store_product`.`code_path`, `store_product`.`soure_link`, `store_product`.`video_link`, `store_product`.`temp_id`, `store_product`.`spec_type`, `store_product`.`activity`, `store_product`.`spu`, `store_product`.`label_id`, `store_product`.`command_word`, `store_product`.`recommend_list`, `store_product`.`vip_product`, `store_product`.`presale`, `store_product`.`presale_start_time`, `store_product`.`presale_end_time`, `store_product`.`presale_day`, `store_product`.`logistics`, `store_product`.`freight`, `store_product`.`custom_form`, `store_product`.`is_limit`, `store_product`.`limit_type`, `store_product`.`limit_num`, `store_product`.`min_qty`, `store_product`.`default_sku`, `store_product`.`params_list`, `store_product`.`label_list`, `store_product`.`protection_list`, `store_product`.`is_gift`, `store_product`.`gift_price`, `store_product_attr`.`id` AS attr_id, `store_product_attr`.`product_id` AS attr_product_id, `store_product_attr`.`attr_name` AS attr_attr_name, `store_product_attr`.`attr_values` AS attr_attr_values, `store_product_attr`.`type` AS attr_type").
		Joins("LEFT JOIN `eb_store_product_attr` AS store_product_attr ON `store_product_attr`.`product_id` = `store_product`.`id`").
		Where("`store_product`.`id` = ?", id).
		Scan(&result).
		Error
	if err != nil {
		return nil, fmt.Errorf("join query failed")
	}
	return &result, nil
}
