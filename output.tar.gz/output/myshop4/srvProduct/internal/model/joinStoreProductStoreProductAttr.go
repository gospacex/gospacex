package model

// joinStoreProductStoreProductAttr.go 联表 Model
// 左表: StoreProduct (表: eb_store_product)
// 右表: StoreProductAttr (表: eb_store_product_attr, 别名前缀: store_product_attr_)

// JoinStoreProductStoreProductAttr 联表查询结果（扁平结构）
type JoinStoreProductStoreProductAttr struct {
	// 商品id
	Id int64 `gorm:"column:id;comment:商品id"`
	// 商户Id(0为总后台管理员创建,不为0的时候是商户后台创建)
	MerId int64 `gorm:"column:mer_id;comment:商户Id(0为总后台管理员创建,不为0的时候是商户后台创建)"`
	// 商品图片
	Image string `gorm:"column:image;comment:商品图片"`
	// 推荐图
	RecommendImage string `gorm:"column:recommend_image;comment:推荐图"`
	// 轮播图
	SliderImage string `gorm:"column:slider_image;comment:轮播图"`
	// 商品名称
	StoreName string `gorm:"column:store_name;comment:商品名称"`
	// 商品简介
	StoreInfo string `gorm:"column:store_info;comment:商品简介"`
	// 关键字
	Keyword string `gorm:"column:keyword;comment:关键字"`
	// 商品条码（一维码）
	BarCode string `gorm:"column:bar_code;comment:商品条码（一维码）"`
	// 分类id
	CateId string `gorm:"column:cate_id;comment:分类id"`
	// 商品价格
	Price float64 `gorm:"column:price;comment:商品价格"`
	// 会员价格
	VipPrice float64 `gorm:"column:vip_price;comment:会员价格"`
	// 市场价
	OtPrice float64 `gorm:"column:ot_price;comment:市场价"`
	// 邮费
	Postage float64 `gorm:"column:postage;comment:邮费"`
	// 单位名
	UnitName string `gorm:"column:unit_name;comment:单位名"`
	// 排序
	Sort int64 `gorm:"column:sort;comment:排序"`
	// 销量
	Sales int64 `gorm:"column:sales;comment:销量"`
	// 库存
	Stock int64 `gorm:"column:stock;comment:库存"`
	// 状态（0：未上架，1：上架）
	IsShow bool `gorm:"column:is_show;comment:状态（0：未上架，1：上架）"`
	// 是否热卖
	IsHot bool `gorm:"column:is_hot;comment:是否热卖"`
	// 是否优惠
	IsBenefit bool `gorm:"column:is_benefit;comment:是否优惠"`
	// 是否精品
	IsBest bool `gorm:"column:is_best;comment:是否精品"`
	// 是否新品
	IsNew bool `gorm:"column:is_new;comment:是否新品"`
	// 商品是否是虚拟商品
	IsVirtual bool `gorm:"column:is_virtual;comment:商品是否是虚拟商品"`
	// 虚拟商品类型
	VirtualType int64 `gorm:"column:virtual_type;comment:虚拟商品类型"`
	// 添加时间
	AddTime int64 `gorm:"column:add_time;comment:添加时间"`
	// 是否包邮
	IsPostage bool `gorm:"column:is_postage;comment:是否包邮"`
	// 是否删除
	IsDel bool `gorm:"column:is_del;comment:是否删除"`
	// 商户是否代理 0不可代理1可代理
	MerUse int64 `gorm:"column:mer_use;comment:商户是否代理 0不可代理1可代理"`
	// 获得积分
	GiveIntegral int64 `gorm:"column:give_integral;comment:获得积分"`
	// 成本价
	Cost float64 `gorm:"column:cost;comment:成本价"`
	// 秒杀状态 0 未开启 1已开启
	IsSeckill bool `gorm:"column:is_seckill;comment:秒杀状态 0 未开启 1已开启"`
	// 砍价状态 0未开启 1开启
	IsBargain bool `gorm:"column:is_bargain;comment:砍价状态 0未开启 1开启"`
	// 是否优品推荐
	IsGood bool `gorm:"column:is_good;comment:是否优品推荐"`
	// 是否单独分佣
	IsSub bool `gorm:"column:is_sub;comment:是否单独分佣"`
	// 是否开启会员价格
	IsVip bool `gorm:"column:is_vip;comment:是否开启会员价格"`
	// 虚拟销量
	Ficti int64 `gorm:"column:ficti;comment:虚拟销量"`
	// 浏览量
	Browse int64 `gorm:"column:browse;comment:浏览量"`
	// 商品二维码地址(用户小程序海报)
	CodePath string `gorm:"column:code_path;comment:商品二维码地址(用户小程序海报)"`
	// 淘宝京东1688类型
	SoureLink string `gorm:"column:soure_link;comment:淘宝京东1688类型"`
	// 主图视频链接
	VideoLink string `gorm:"column:video_link;comment:主图视频链接"`
	// 运费模板ID
	TempId int64 `gorm:"column:temp_id;comment:运费模板ID"`
	// 规格 0单 1多
	SpecType int64 `gorm:"column:spec_type;comment:规格 0单 1多"`
	// 活动显示排序1=秒杀，2=砍价，3=拼团
	Activity string `gorm:"column:activity;comment:活动显示排序1=秒杀，2=砍价，3=拼团"`
	// 商品SPU
	Spu string `gorm:"column:spu;comment:商品SPU"`
	// 标签ID
	LabelId string `gorm:"column:label_id;comment:标签ID"`
	// 复制口令
	CommandWord string `gorm:"column:command_word;comment:复制口令"`
	// 推荐商品id
	RecommendList string `gorm:"column:recommend_list;comment:推荐商品id"`
	// 是否会员专属商品
	VipProduct int64 `gorm:"column:vip_product;comment:是否会员专属商品"`
	// 是否预售商品
	Presale int64 `gorm:"column:presale;comment:是否预售商品"`
	// 预售开始时间
	PresaleStartTime int64 `gorm:"column:presale_start_time;comment:预售开始时间"`
	// 预售结束时间
	PresaleEndTime int64 `gorm:"column:presale_end_time;comment:预售结束时间"`
	// 预售结束后几天内发货
	PresaleDay int64 `gorm:"column:presale_day;comment:预售结束后几天内发货"`
	// 物流方式
	Logistics string `gorm:"column:logistics;comment:物流方式"`
	// 运费设置
	Freight int64 `gorm:"column:freight;comment:运费设置"`
	// 自定义表单
	CustomForm string `gorm:"column:custom_form;comment:自定义表单"`
	// 是否开启限购
	IsLimit bool `gorm:"column:is_limit;comment:是否开启限购"`
	// 限购类型1单次限购2永久限购
	LimitType int64 `gorm:"column:limit_type;comment:限购类型1单次限购2永久限购"`
	// 限购数量
	LimitNum int64 `gorm:"column:limit_num;comment:限购数量"`
	// 起购数量
	MinQty int64 `gorm:"column:min_qty;comment:起购数量"`
	// 默认规格
	DefaultSku string `gorm:"column:default_sku;comment:默认规格"`
	// 商品参数
	ParamsList string `gorm:"column:params_list;comment:商品参数"`
	// 商品标签
	LabelList string `gorm:"column:label_list;comment:商品标签"`
	// 商品保障
	ProtectionList string `gorm:"column:protection_list;comment:商品保障"`
	// 是否是礼品
	IsGift int64 `gorm:"column:is_gift;comment:是否是礼品"`
	// 礼品附加费
	GiftPrice float64 `gorm:"column:gift_price;comment:礼品附加费"`
	// 自增ID
	AttrId int64 `gorm:"column:attr_id;comment:自增ID"`
	// 商品ID
	AttrProductId int64 `gorm:"column:attr_product_id;comment:商品ID"`
	// 属性名
	AttrAttrName string `gorm:"column:attr_attr_name;comment:属性名"`
	// 属性值
	AttrAttrValues string `gorm:"column:attr_attr_values;comment:属性值"`
	// 活动类型 0=商品，1=秒杀，2=砍价，3=拼团
	AttrType int64 `gorm:"column:attr_type;comment:活动类型 0=商品，1=秒杀，2=砍价，3=拼团"`
}