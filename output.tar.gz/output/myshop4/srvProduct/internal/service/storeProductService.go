package service

import (
	"context"

	"myshop4/srvProduct/internal/model"
	"myshop4/srvProduct/internal/repository"
	pb "myshop4/common/kitexGen/storeProduct"
)

type StoreProductService struct { repo *repository.StoreProductRepo }

func NewStoreProductService(repo *repository.StoreProductRepo) *StoreProductService {
	return &StoreProductService{repo: repo}
}

func (s *StoreProductService) Create(ctx context.Context, m *model.StoreProduct) error {
	return s.repo.Create(ctx, m)
}

func (s *StoreProductService) Get(ctx context.Context, id int64) (*model.StoreProduct, error) {
	return s.repo.GetByID(ctx, id)
}

// ListWithFilter 支持分页和过滤条件的列表查询
func (s *StoreProductService) ListWithFilter(ctx context.Context, req *pb.ListStoreProductReq) ([]*model.StoreProduct, error) {
	return s.repo.ListWithFilter(ctx, req)
}

func (s *StoreProductService) Update(ctx context.Context, m *model.StoreProduct) error {
	return s.repo.Update(ctx, m)
}

func (s *StoreProductService) Delete(ctx context.Context, id int64) error {
	return s.repo.Delete(ctx, id)
}
// GetStoreProductStoreProductAttr 获取联表数据
func (s *StoreProductService) GetStoreProductStoreProductAttr(ctx context.Context, id int64) (*model.JoinStoreProductStoreProductAttr, error) {
	return s.repo.FindStoreProduct2StoreProductAttr(ctx, id)
}