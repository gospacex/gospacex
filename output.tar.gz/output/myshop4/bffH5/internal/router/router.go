package router

import (
	"myshop4/bffH5/internal/handler"
	"github.com/gin-gonic/gin"
)

func NewRouter() *gin.Engine {
	r := gin.Default()
	r.GET("/api/v1/storeProducts", handler.NewStoreProductHandler().List)
	r.GET("/api/v1/storeProducts/:id", handler.NewStoreProductHandler().Get)
	r.POST("/api/v1/storeProducts", handler.NewStoreProductHandler().Create)
	r.PUT("/api/v1/storeProducts/:id", handler.NewStoreProductHandler().Update)
	r.DELETE("/api/v1/storeProducts/:id", handler.NewStoreProductHandler().Delete)
	r.GET("/api/v1/storeProductStoreProductAttrs/:id", handler.NewStoreProductHandler().GetJoinStoreProductStoreProductAttr)
	return r
}
