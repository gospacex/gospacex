#!/bin/bash
# Service gRPC Test Script
# Usage: bash run_srv_tests.sh

set -e

SRV_PORT=8001
SRV_HOST=${SRV_HOST:-localhost}
PROTO_FILE="common/idl/storeProduct.proto"

echo "=========================================="
echo "Service gRPC Testing"
echo "Target: ${SRV_HOST}:${SRV_PORT}"
echo "=========================================="

# 检查 grpcurl 是否安装
if ! command -v grpcurl &> /dev/null; then
    echo "⚠️  grpcurl not found. Install with:"
    echo "    go install github.com/fullstorydev/grpcurl/cmd/grpcurl@latest"
    exit 1
fi

# 检查服务是否运行
check_service() {
    if ! grpcurl -plaintext "${SRV_HOST}:${SRV_PORT}" list &>/dev/null; then
        echo "⚠️  Warning: Service may not be running at ${SRV_HOST}:${SRV_PORT}"
        echo "   Run: cd srvProduct && go run cmd/main.go"
    fi
}

check_service

echo ""
echo "--- List available services ---"
grpcurl -plaintext "${SRV_HOST}:${SRV_PORT}" list
echo ""


echo "--- Test: StoreProductService/Create ---"
CREATE_RESP=$(grpcurl -plaintext -d '{"store_name": "Test Product", "price": 99.9}' "${SRV_HOST}:${SRV_PORT}" storeProduct.StoreProductService/Create)
echo "$CREATE_RESP"
CREATED_ID=$(echo "$CREATE_RESP" | grep -o '"id"[[:space:]]*:[[:space:]]*"[^"]*"' | grep -o '[0-9]\+' | head -1)
if [ -z "$CREATED_ID" ]; then
    CREATED_ID="3"
fi
echo ""

echo "--- Test: StoreProductService/List ---"
grpcurl -plaintext -d '{}' "${SRV_HOST}:${SRV_PORT}" storeProduct.StoreProductService/List
echo ""

echo "--- Test: StoreProductService/Get (ID=${CREATED_ID}) ---"
grpcurl -plaintext -d "{\"id\": ${CREATED_ID}}" "${SRV_HOST}:${SRV_PORT}" storeProduct.StoreProductService/Get
echo ""

echo "--- Test: StoreProductService/Update (ID=${CREATED_ID}) ---"
grpcurl -plaintext -d "{\"id\": ${CREATED_ID}, \"store_name\": \"Updated Product\"}" "${SRV_HOST}:${SRV_PORT}" storeProduct.StoreProductService/Update
echo ""

echo "--- Test: StoreProductService/Delete (ID=${CREATED_ID}) ---"
grpcurl -plaintext -d "{\"id\": ${CREATED_ID}}" "${SRV_HOST}:${SRV_PORT}" storeProduct.StoreProductService/Delete
echo ""



echo ""
echo "=========================================="
echo "  JOIN Tests (1t1)"
echo "=========================================="

echo ""
echo "--- Test: JoinGetStoreProductStoreProductAttr (ID=3) ---"
grpcurl -plaintext -d '{"id": 3}' "${SRV_HOST}:${SRV_PORT}" storeProduct.StoreProductService/JoinGetStoreProductStoreProductAttr
echo ""


echo "=========================================="
echo "Service Tests Complete!"
echo "=========================================="