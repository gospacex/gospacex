#!/bin/bash
# BFF HTTP Test Script
# Usage: bash run_bff_tests.sh

set -e

BFF_PORT=8080
BFF_HOST=${BFF_HOST:-localhost}
BASE_URL="http://${BFF_HOST}:${BFF_PORT}"

echo "=========================================="
echo "BFF HTTP Testing"
echo "Base URL: ${BASE_URL}"
echo "=========================================="

# 检查服务是否运行
check_service() {
    if ! curl -s -o /dev/null -w "%{http_code}" "${BASE_URL}/health" | grep -q "200"; then
        echo "⚠️  Warning: Service may not be running at ${BASE_URL}"
        echo "   Run: cd bffH5 && go run cmd/main.go"
    fi
}

check_service

echo ""
echo "--- Test: Health Check ---"
curl -s "${BASE_URL}/health" | head -c 100
echo ""
echo ""


echo "--- Test: Create Product ---"
RESPONSE=$(curl -s -X POST "${BASE_URL}/api/v1/storeProducts" -H "Content-Type: application/json" -d '{}')
echo "$RESPONSE" | head -c 200
echo ""
echo ""

# 提取创建的 ID
CREATED_ID=$(echo "$RESPONSE" | grep -o '"id":[0-9]*' | grep -o '[0-9]*' | head -1)
if [ -z "$CREATED_ID" ]; then
    CREATED_ID="2"
fi

echo "--- Test: List Product ---"
curl -s "${BASE_URL}/api/v1/storeProducts" | head -c 200
echo ""
echo ""

echo "--- Test: Get Product (ID=${CREATED_ID}) ---"
curl -s "${BASE_URL}/api/v1/storeProducts/${CREATED_ID}" | head -c 200
echo ""
echo ""

echo "--- Test: Update Product (ID=${CREATED_ID}) ---"
curl -s -X PUT "${BASE_URL}/api/v1/storeProducts/${CREATED_ID}" -H "Content-Type: application/json" -d '{"store_name": "Updated Product"}' | head -c 200
echo ""
echo ""

echo "--- Test: Delete Product (ID=${CREATED_ID}) ---"
curl -s -X DELETE "${BASE_URL}/api/v1/storeProducts/${CREATED_ID}" | head -c 200
echo ""
echo ""


echo "=========================================="
echo "BFF Tests Complete!"
echo "=========================================="