package test

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
)

// ------------------------------------------------------------------
// Mock HTTP handlers (simulating BFF handler responses)
// ------------------------------------------------------------------


type mockProductHandler struct{}

func (h *mockProductHandler) ListProduct(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"items": []map[string]interface{}{
			{"id": float64(1), "store_name": "Mock Product 1", "price": 10.0},
			{"id": float64(2), "store_name": "Mock Product 2", "price": 20.0},
		},
	})
}

func (h *mockProductHandler) GetProduct(c *gin.Context) {
	id := c.Param("id")
	if id == "999" {
		c.JSON(http.StatusNotFound, gin.H{"error": "record not found"})
		return
	}
	c.JSON(http.StatusOK, gin.H{
		"id":         id,
		"store_name":  "Mock Product",
		"price":      99.9,
		"is_show":    true,
	})
}

func (h *mockProductHandler) CreateProduct(c *gin.Context) {
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"id": 1})
}

func (h *mockProductHandler) UpdateProduct(c *gin.Context) {
	id := c.Param("id")
	var req map[string]interface{}
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	_ = id
	c.JSON(http.StatusOK, gin.H{"success": true})
}

func (h *mockProductHandler) DeleteProduct(c *gin.Context) {
	id := c.Param("id")
	_ = id
	c.JSON(http.StatusOK, gin.H{"success": true})
}

// setupProductRouter 创建测试用 Gin router
func setupProductRouter() *gin.Engine {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	h := &mockProductHandler{}
	r.GET("/api/v1/storeProducts", h.ListProduct)
	r.GET("/api/v1/storeProducts/:id", h.GetProduct)
	r.POST("/api/v1/storeProducts", h.CreateProduct)
	r.PUT("/api/v1/storeProducts/:id", h.UpdateProduct)
	r.DELETE("/api/v1/storeProducts/:id", h.DeleteProduct)
	return r
}

// ------------------------------------------------------------------
// Tests
// ------------------------------------------------------------------

func TestProductHandler_List(t *testing.T) {
	r := setupProductRouter()
	req := httptest.NewRequest(http.MethodGet, "/api/v1/storeProducts", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected status 200, got %d, body: %s", w.Code, w.Body.String())
	}

	var resp map[string]interface{}
	if err := json.Unmarshal(w.Body.Bytes(), &resp); err != nil {
		t.Fatalf("failed to parse response: %v", err)
	}
	items, ok := resp["items"].([]interface{})
	if !ok || len(items) == 0 {
		t.Error("expected non-empty items")
	}
}

func TestProductHandler_Get(t *testing.T) {
	r := setupProductRouter()
	req := httptest.NewRequest(http.MethodGet, "/api/v1/storeProducts/5", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected status 200, got %d", w.Code)
	}

	var resp map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &resp)
	if resp["store_name"] != "Mock Product" {
		t.Errorf("unexpected store_name: %v", resp["store_name"])
	}
}

func TestProductHandler_Get_NotFound(t *testing.T) {
	r := setupProductRouter()
	req := httptest.NewRequest(http.MethodGet, "/api/v1/storeProducts/999", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	if w.Code != http.StatusNotFound {
		t.Errorf("expected status 404, got %d", w.Code)
	}
}

func TestProductHandler_Create(t *testing.T) {
	r := setupProductRouter()
	body := `{"store_name":"New Product","price":88.8}`
	req := httptest.NewRequest(http.MethodPost, "/api/v1/storeProducts", bytes.NewBufferString(body))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected status 200, got %d, body: %s", w.Code, w.Body.String())
	}

	var resp map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &resp)
	if resp["id"] != float64(1) {
		t.Errorf("expected id=1, got %v", resp["id"])
	}
}

func TestProductHandler_Create_InvalidJSON(t *testing.T) {
	r := setupProductRouter()
	body := `{invalid json}`
	req := httptest.NewRequest(http.MethodPost, "/api/v1/storeProducts", bytes.NewBufferString(body))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Errorf("expected status 400, got %d, body: %s", w.Code, w.Body.String())
	}
}

func TestProductHandler_Update(t *testing.T) {
	r := setupProductRouter()
	body := `{"store_name":"Updated Name","price":199.0}`
	req := httptest.NewRequest(http.MethodPut, "/api/v1/storeProducts/1", bytes.NewBufferString(body))
	req.Header.Set("Content-Type", "application/json")
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected status 200, got %d", w.Code)
	}

	var resp map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &resp)
	if resp["success"] != true {
		t.Errorf("expected success=true")
	}
}

func TestProductHandler_Delete(t *testing.T) {
	r := setupProductRouter()
	req := httptest.NewRequest(http.MethodDelete, "/api/v1/storeProducts/1", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Errorf("expected status 200, got %d", w.Code)
	}

	var resp map[string]interface{}
	json.Unmarshal(w.Body.Bytes(), &resp)
	if resp["success"] != true {
		t.Errorf("expected success=true")
	}
}



func TestResponseContentType(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.GET("/test", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"ok": true})
	})
	req := httptest.NewRequest(http.MethodGet, "/test", nil)
	w := httptest.NewRecorder()
	r.ServeHTTP(w, req)

	if ct := w.Header().Get("Content-Type"); ct == "" {
		t.Error("expected Content-Type header to be set")
	} else {
		t.Logf("Content-Type: %s", ct)
	}
}