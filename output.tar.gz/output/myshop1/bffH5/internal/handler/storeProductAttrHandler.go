package handler

import (
	"net/http"
	"strconv"
	"time"
	"myshop1/pkg/logger"
	"myshop1/bffH5/internal/rpcClient"
	pb "myshop1/common/kitexGen/storeProductAttr"

	"github.com/gin-gonic/gin"
)

type StoreProductAttrHandler struct {
	client rpcclient.StoreProductAttrServiceClientInterface
}

func NewStoreProductAttrHandler() *StoreProductAttrHandler {
	return NewStoreProductAttrHandlerWithClient("127.0.0.1:50050")
}

func NewStoreProductAttrHandlerWithClient(grpcAddr string) *StoreProductAttrHandler {
	cli, err := rpcclient.NewStoreProductAttrClient(grpcAddr)
	if err != nil {
		logger.Business.Errorw("failed to create storeProductAttr client", "error", err.Error())
		panic("failed to create storeProductAttr client: " + err.Error())
	}
	logger.Business.Infow("StoreProductAttrHandler initialized", "addr", grpcAddr)
	return &StoreProductAttrHandler{client: cli}
}

func (h *StoreProductAttrHandler) Create(c *gin.Context) {
	start := time.Now()
	requestID, _ := c.Get("requestID")
	logger.Access.Infow("create request start", "method", c.Request.Method, "path", c.Request.URL.Path, "requestID", requestID)
	logger.Business.Infow("create storeProductAttr start", "requestID", requestID)

	var req struct {
		ProductId int64 `json:"product_id"`
		AttrName string `json:"attr_name"`
		AttrValues string `json:"attr_values"`
		Type int64 `json:"type"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Business.Errorw("bind create request failed", "error", err.Error(), "requestID", requestID)
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	rpcReq := &pb.CreateStoreProductAttrReq{
		ProductId: req.ProductId,
		AttrName: req.AttrName,
		AttrValues: req.AttrValues,
		Type: req.Type,
	}

	resp, err := h.client.Create(c.Request.Context(), rpcReq)
	if err != nil {
		logger.Business.Errorw("create storeProductAttr failed", "error", err.Error(), "requestID", requestID)
		logger.Audit.Errorw("audit: create storeProductAttr failed", "error", err.Error(), "requestID", requestID)
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	logger.Business.Infow("create storeProductAttr success", "id", resp.Id, "duration", time.Since(start).String())
	logger.Audit.Infow("audit: create storeProductAttr success", "id", resp.Id, "requestID", requestID)
	c.JSON(http.StatusOK, gin.H{"id": resp.Id})
}

func (h *StoreProductAttrHandler) Get(c *gin.Context) {
	start := time.Now()
	requestID, _ := c.Get("requestID")
	idStr := c.Param("id")
	logger.Business.Infow("get storeProductAttr start", "id", idStr, "requestID", requestID)

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		logger.Business.Errorw("invalid id", "id", idStr, "error", err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	resp, err := h.client.Get(c.Request.Context(), int64(id))
	if err != nil {
		logger.Business.Errorw("get storeProductAttr failed", "id", id, "error", err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	logger.Business.Infow("get storeProductAttr success", "id", id, "duration", time.Since(start).String())
	c.JSON(http.StatusOK, gin.H{
		"id": resp.Id,
		"product_id": resp.ProductId,
		"attr_name": resp.AttrName,
		"attr_values": resp.AttrValues,
		"type": resp.Type,
	})
}

func (h *StoreProductAttrHandler) List(c *gin.Context) {
	start := time.Now()
	requestID, _ := c.Get("requestID")
	logger.Business.Infow("list storeProductAttr start", "requestID", requestID)

	resp, err := h.client.List(c.Request.Context())
	if err != nil {
		logger.Business.Errorw("list storeProductAttr failed", "error", err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	var items []map[string]interface{}
	for _, item := range resp.Items {
		items = append(items, map[string]interface{}{
			"id": item.Id,
			"product_id": item.ProductId,
			"attr_name": item.AttrName,
			"attr_values": item.AttrValues,
			"type": item.Type,
		})
	}
	logger.Business.Infow("list storeProductAttr success", "count", len(items), "duration", time.Since(start).String())
	c.JSON(http.StatusOK, gin.H{"items": items})
}

func (h *StoreProductAttrHandler) Update(c *gin.Context) {
	start := time.Now()
	requestID, _ := c.Get("requestID")
	idStr := c.Param("id")
	logger.Business.Infow("update storeProductAttr start", "id", idStr, "requestID", requestID)

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		logger.Business.Errorw("invalid id", "id", idStr, "error", err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	var req struct {
		ProductId int64 `json:"product_id"`
		AttrName string `json:"attr_name"`
		AttrValues string `json:"attr_values"`
		Type int64 `json:"type"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		logger.Business.Errorw("bind update request failed", "error", err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	rpcReq := &pb.UpdateStoreProductAttrReq{
		Id: int64(id),
		ProductId: req.ProductId,
		AttrName: req.AttrName,
		AttrValues: req.AttrValues,
		Type: req.Type,
	}

	resp, err := h.client.Update(c.Request.Context(), rpcReq)
	if err != nil {
		logger.Business.Errorw("update storeProductAttr failed", "id", id, "error", err.Error())
		logger.Audit.Errorw("audit: update storeProductAttr failed", "id", id, "error", err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	logger.Business.Infow("update storeProductAttr success", "id", id, "duration", time.Since(start).String())
	logger.Audit.Infow("audit: update storeProductAttr success", "id", id, "requestID", requestID)
	c.JSON(http.StatusOK, gin.H{"success": resp.Success})
}

func (h *StoreProductAttrHandler) Delete(c *gin.Context) {
	start := time.Now()
	requestID, _ := c.Get("requestID")
	idStr := c.Param("id")
	logger.Business.Infow("delete storeProductAttr start", "id", idStr, "requestID", requestID)

	id, err := strconv.ParseInt(idStr, 10, 64)
	if err != nil {
		logger.Business.Errorw("invalid id", "id", idStr, "error", err.Error())
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	resp, err := h.client.Delete(c.Request.Context(), int64(id))
	if err != nil {
		logger.Business.Errorw("delete storeProductAttr failed", "id", id, "error", err.Error())
		logger.Audit.Errorw("audit: delete storeProductAttr failed", "id", id, "error", err.Error())
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	logger.Business.Infow("delete storeProductAttr success", "id", id, "duration", time.Since(start).String())
	logger.Audit.Infow("audit: delete storeProductAttr success", "id", id, "requestID", requestID)
	c.JSON(http.StatusOK, gin.H{"success": resp.Success})
}
