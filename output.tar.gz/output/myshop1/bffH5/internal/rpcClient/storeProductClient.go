package rpcclient

import (
	"context"

	pb "myshop1/common/kitexGen/storeProduct"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

// StoreProductServiceClientInterface 定义 gRPC 客户端接口，方便单元测试 mock
type StoreProductServiceClientInterface interface {
	Create(ctx context.Context, req *pb.CreateStoreProductReq) (*pb.CreateStoreProductResp, error)
	Get(ctx context.Context, id int64) (*pb.GetStoreProductResp, error)
	List(ctx context.Context) (*pb.ListStoreProductResp, error)
	Update(ctx context.Context, req *pb.UpdateStoreProductReq) (*pb.UpdateStoreProductResp, error)
	Delete(ctx context.Context, id int64) (*pb.DeleteStoreProductResp, error)
}

type StoreProductClient struct {
	conn   *grpc.ClientConn
	client pb.StoreProductServiceClient
}

var _ StoreProductServiceClientInterface = (*StoreProductClient)(nil)

func NewStoreProductClient(addr string) (*StoreProductClient, error) {
	conn, err := grpc.Dial(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, err
	}
	return &StoreProductClient{conn: conn, client: pb.NewStoreProductServiceClient(conn)}, nil
}

func (c *StoreProductClient) Close() error {
	if c.conn != nil {
		return c.conn.Close()
	}
	return nil
}

func (c *StoreProductClient) Create(ctx context.Context, req *pb.CreateStoreProductReq) (*pb.CreateStoreProductResp, error) {
	return c.client.Create(ctx, req)
}

func (c *StoreProductClient) Get(ctx context.Context, id int64) (*pb.GetStoreProductResp, error) {
	return c.client.Get(ctx, &pb.GetStoreProductReq{ Id: id })
}

func (c *StoreProductClient) List(ctx context.Context) (*pb.ListStoreProductResp, error) {
	return c.client.List(ctx, &pb.ListStoreProductReq{})
}

func (c *StoreProductClient) Update(ctx context.Context, req *pb.UpdateStoreProductReq) (*pb.UpdateStoreProductResp, error) {
	return c.client.Update(ctx, req)
}

func (c *StoreProductClient) Delete(ctx context.Context, id int64) (*pb.DeleteStoreProductResp, error) {
	return c.client.Delete(ctx, &pb.DeleteStoreProductReq{ Id: id })
}