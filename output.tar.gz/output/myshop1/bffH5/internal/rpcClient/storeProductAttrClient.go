package rpcclient

import (
	"context"

	pb "myshop1/common/kitexGen/storeProductAttr"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

// StoreProductAttrServiceClientInterface 定义 gRPC 客户端接口，方便单元测试 mock
type StoreProductAttrServiceClientInterface interface {
	Create(ctx context.Context, req *pb.CreateStoreProductAttrReq) (*pb.CreateStoreProductAttrResp, error)
	Get(ctx context.Context, id int64) (*pb.GetStoreProductAttrResp, error)
	List(ctx context.Context) (*pb.ListStoreProductAttrResp, error)
	Update(ctx context.Context, req *pb.UpdateStoreProductAttrReq) (*pb.UpdateStoreProductAttrResp, error)
	Delete(ctx context.Context, id int64) (*pb.DeleteStoreProductAttrResp, error)
}

type StoreProductAttrClient struct {
	conn   *grpc.ClientConn
	client pb.StoreProductAttrServiceClient
}

var _ StoreProductAttrServiceClientInterface = (*StoreProductAttrClient)(nil)

func NewStoreProductAttrClient(addr string) (*StoreProductAttrClient, error) {
	conn, err := grpc.Dial(addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		return nil, err
	}
	return &StoreProductAttrClient{conn: conn, client: pb.NewStoreProductAttrServiceClient(conn)}, nil
}

func (c *StoreProductAttrClient) Close() error {
	if c.conn != nil {
		return c.conn.Close()
	}
	return nil
}

func (c *StoreProductAttrClient) Create(ctx context.Context, req *pb.CreateStoreProductAttrReq) (*pb.CreateStoreProductAttrResp, error) {
	return c.client.Create(ctx, req)
}

func (c *StoreProductAttrClient) Get(ctx context.Context, id int64) (*pb.GetStoreProductAttrResp, error) {
	return c.client.Get(ctx, &pb.GetStoreProductAttrReq{ Id: id })
}

func (c *StoreProductAttrClient) List(ctx context.Context) (*pb.ListStoreProductAttrResp, error) {
	return c.client.List(ctx, &pb.ListStoreProductAttrReq{})
}

func (c *StoreProductAttrClient) Update(ctx context.Context, req *pb.UpdateStoreProductAttrReq) (*pb.UpdateStoreProductAttrResp, error) {
	return c.client.Update(ctx, req)
}

func (c *StoreProductAttrClient) Delete(ctx context.Context, id int64) (*pb.DeleteStoreProductAttrResp, error) {
	return c.client.Delete(ctx, &pb.DeleteStoreProductAttrReq{ Id: id })
}