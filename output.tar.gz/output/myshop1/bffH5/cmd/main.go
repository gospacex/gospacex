package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"

	"myshop1/pkg/config"
	"myshop1/pkg/logger"
	"myshop1/bffH5/internal/router"

)

var confPath string

func init() {
	flag.StringVar(&confPath, "config", "configs/config.yaml", "config file")
}

func main() {
	flag.Parse()
	cfg, err := config.Load(confPath)
	if err != nil {
		log.Fatal(err)
	}
	if cfg == nil {
		log.Fatal("Config is nil - check if config file exists: " + confPath)
	}

	logCfg, err := logger.LoadConfig(confPath)
	if err != nil {
		log.Fatal(err)
	}
	l, err := logger.NewLogger(logCfg)
	if err != nil {
		log.Fatal(err)
	}
	defer l.Sync()

	logger.Business.Infow("BFF 服务启动", "host", cfg.Server.Host, "port", cfg.Server.Port)

	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	logger.Business.Infow("BFF listening", "addr", addr)

	srv := &http.Server{
		Addr:    addr,
		Handler: router.NewRouter(),
	}

	go func() {
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Error.Errorw("listen error", "error", err.Error())
		}
	}()

	select {}
}
