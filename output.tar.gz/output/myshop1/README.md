# myshop1

Microservice project.

## Options

- **Protocol**: grpc
- **HTTP**: gin
- **IDL**: proto

## Structure
```
myshop1/
├── bffH5/
├── srvProduct/
├── common/
├── pkg/
├── bffH5/test/     ← BFF 接口测试
├── srvProduct/test/     ← product 微服接口测试
└── scripts/
```

## Build
```bash
go mod init github.com/yourorg/myshop1
./scripts/gen_proto.sh
./scripts/build.sh
```

## Test
```bash
# 运行 BFF 层接口测试
cd bffH5 && go test ./test/ -v

# 运行 product 微服层接口测试
cd srvProduct && go test ./test/ -v

```
