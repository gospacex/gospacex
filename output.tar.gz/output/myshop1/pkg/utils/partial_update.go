package utils

import (
	"reflect"

	"github.com/jinzhu/copier"
)

// PartialUpdate 将 src 中非零值字段合并到 dst
// 对于结构体指针 dst 和 src，只更新 src 中非零值的字段，零值字段保持 dst 原值不变
func PartialUpdate(dst, src interface{}) error {
	dstVal := reflect.ValueOf(dst).Elem()
	srcVal := reflect.ValueOf(src).Elem()

	// 临时创建目标对象的副本，用于保存原始值
	tmpVal := reflect.New(dstVal.Type()).Elem()
	tmpVal.Set(dstVal)

	// 先进行全量复制
	if err := copier.Copy(dst, src); err != nil {
		return err
	}

	// 遍历 src 的所有字段
	for i := 0; i < srcVal.NumField(); i++ {
		srcField := srcVal.Field(i)

		// 如果 src 字段是零值，将 dst 字段恢复为原始值
		if IsZeroValue(srcField) {
			dstField := dstVal.Field(i)
			tmpField := tmpVal.Field(i)
			if dstField.CanSet() {
				dstField.Set(tmpField)
			}
		}
	}

	return nil
}

// IsZeroValue 判断反射值是否为零值
func IsZeroValue(v reflect.Value) bool {
	switch v.Kind() {
	case reflect.String:
		return v.String() == ""
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return v.Int() == 0
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		return v.Uint() == 0
	case reflect.Float32, reflect.Float64:
		return v.Float() == 0
	case reflect.Bool:
		return !v.Bool()
	case reflect.Ptr, reflect.Interface:
		return v.IsNil()
	case reflect.Slice, reflect.Map, reflect.Array:
		return v.Len() == 0
	default:
		return false
	}
}
