package logger

import (
	"context"

	"go.uber.org/zap"
)

type AccessLogger struct {
	*zap.SugaredLogger
}

func NewAccessLogger(logger *zap.Logger) *AccessLogger {
	return &AccessLogger{
		logger.Named("access").Sugar(),
	}
}

type AccessLog struct {
	Method    string `json:"method"`
	Path      string `json:"path"`
	Status    int    `json:"status"`
	Latency   int64  `json:"latency_ms"`
	ClientIP  string `json:"client_ip"`
	UserAgent string `json:"user_agent"`
	RequestID string `json:"request_id"`
}

func (l *AccessLogger) Log(method, path, clientIP, userAgent, requestID string, status int, latency int64) {
	l.Infow("access",
		"method", method,
		"path", path,
		"status", status,
		"latency_ms", latency,
		"client_ip", clientIP,
		"user_agent", userAgent,
		"request_id", requestID,
	)
}

func (l *AccessLogger) LogWithContext(ctx context.Context, method, path, clientIP, userAgent, requestID string, status int, latency int64) {
	fields := []interface{}{
		"method", method,
		"path", path,
		"status", status,
		"latency_ms", latency,
		"client_ip", clientIP,
		"user_agent", userAgent,
		"request_id", requestID,
	}
	if traceID := getTraceID(ctx); traceID != "" {
		fields = append(fields, "trace_id", traceID)
	}
	l.Infow("access", fields...)
}

func (l *AccessLogger) With(keysAndValues ...interface{}) *AccessLogger {
	return &AccessLogger{l.SugaredLogger.With(keysAndValues...)}
}

func (l *AccessLogger) WithContext(ctx context.Context) *AccessLogger {
	if traceID := getTraceID(ctx); traceID != "" {
		return &AccessLogger{l.SugaredLogger.With("trace_id", traceID)}
	}
	return &AccessLogger{l.SugaredLogger}
}
