package logger

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type RotationWriter struct {
	dir         string
	baseName    string
	currentFile *os.File
	currentDate string
	mu          sync.Mutex
}

func NewRotationWriter(dir, baseName string) (*RotationWriter, error) {
	if err := os.MkdirAll(dir, 0755); err != nil {
		return nil, err
	}

	r := &RotationWriter{
		dir:      dir,
		baseName: baseName,
	}
	if err := r.rotate(); err != nil {
		return nil, err
	}
	return r, nil
}

func (r *RotationWriter) rotate() error {
	now := time.Now()
	dateStr := now.Format("2006-01-02")

	if r.currentDate == dateStr && r.currentFile != nil {
		return nil
	}

	if r.currentFile != nil {
		r.currentFile.Close()
	}

	fileName := fmt.Sprintf("%s-%s.log", r.baseName, dateStr)
	filePath := filepath.Join(r.dir, fileName)

	f, err := os.OpenFile(filePath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return err
	}

	r.currentFile = f
	r.currentDate = dateStr
	return nil
}

func (r *RotationWriter) Write(p []byte) (n int, err error) {
	r.mu.Lock()
	defer r.mu.Unlock()

	if err := r.rotate(); err != nil {
		return 0, err
	}

	return r.currentFile.Write(p)
}

func (r *RotationWriter) Sync() error {
	r.mu.Lock()
	defer r.mu.Unlock()

	if r.currentFile != nil {
		return r.currentFile.Sync()
	}
	return nil
}

func (r *RotationWriter) Close() error {
	r.mu.Lock()
	defer r.mu.Unlock()

	if r.currentFile != nil {
		return r.currentFile.Close()
	}
	return nil
}

func GetLogFileDate(fileName string) string {
	ext := filepath.Ext(fileName)
	base := strings.TrimSuffix(fileName, ext)
	parts := strings.Split(base, "-")
	if len(parts) >= 3 {
		return parts[len(parts)-3] + "-" + parts[len(parts)-2] + "-" + parts[len(parts)-1]
	}
	return ""
}
