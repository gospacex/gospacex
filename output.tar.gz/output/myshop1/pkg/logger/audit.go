package logger

import (
	"go.uber.org/zap"
)

type AuditLogger struct {
	*zap.SugaredLogger
}

func NewAuditLogger(logger *zap.Logger) *AuditLogger {
	return &AuditLogger{
		logger.Named("audit").Sugar(),
	}
}

func (l *AuditLogger) Log(action, userID, resource string, details map[string]interface{}) {
	l.Infow(action,
		"user_id", userID,
		"resource", resource,
		"details", details,
	)
}

func (l *AuditLogger) With(keysAndValues ...interface{}) *AuditLogger {
	return &AuditLogger{l.SugaredLogger.With(keysAndValues...)}
}
