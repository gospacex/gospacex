package logger

import (
	"fmt"
	"os"
	"time"

	"gopkg.in/yaml.v3"
	"go.uber.org/zap/zapcore"
)

type Config struct {
	Env        string       `yaml:"env" default:"dev"`
	Level      string       `yaml:"level" default:"info"`
	Sampling   SamplingCfg  `yaml:"sampling"`
	Rotation   RotationCfg  `yaml:"rotation"`
	Output     OutputCfg    `yaml:"output"`
	Prometheus PrometheusCfg `yaml:"prometheus"`
}

type SamplingCfg struct {
	Initial    int           `yaml:"initial" default:"100"`
	Thereafter int           `yaml:"thereafter" default:"200"`
	Tick       time.Duration `yaml:"tick" default:"1s"`
}

type RotationCfg struct {
	Enabled     bool  `yaml:"enabled" default:"true"`
	MaxAgeDays  int   `yaml:"max_age_days" default:"7"`
}

type OutputCfg struct {
	File   string `yaml:"file" default:"./logs/app.log"`
	Stdout bool   `yaml:"stdout" default:"true"`
}

type PrometheusCfg struct {
	Enabled   bool   `yaml:"enabled" default:"true"`
	Namespace string `yaml:"namespace" default:"app"`
	Subsystem string `yaml:"subsystem" default:"log"`
}

func LoadConfig(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	var cfg Config
	if err := yaml.Unmarshal(data, &cfg); err != nil {
		return nil, err
	}

	cfg.setDefaults()

	return &cfg, nil
}

func (c *Config) setDefaults() {
	if c.Env == "" {
		c.Env = "dev"
	}
	if c.Level == "" {
		c.Level = "info"
	}
	if c.Output.File == "" {
		c.Output.File = "./logs/app.log"
	}
	c.Output.Stdout = true
	if c.Sampling.Initial == 0 {
		c.Sampling.Initial = 100
	}
	if c.Sampling.Thereafter == 0 {
		c.Sampling.Thereafter = 200
	}
	if c.Sampling.Tick == 0 {
		c.Sampling.Tick = time.Second
	}
	if c.Rotation.MaxAgeDays == 0 {
		c.Rotation.MaxAgeDays = 7
	}
}

func (c *Config) Validate() error {
	if _, err := zapcore.ParseLevel(c.Level); err != nil {
		return fmt.Errorf("invalid log level %q: %w", c.Level, err)
	}
	return nil
}
