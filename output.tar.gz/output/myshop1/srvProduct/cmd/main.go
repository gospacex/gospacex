package main

import (
	"flag"
	"fmt"
	"log"
	"net"

	storeProduct "myshop1/common/kitexGen/storeProduct"
	"myshop1/pkg/config"
	"myshop1/pkg/database"
	"myshop1/pkg/logger"
	"myshop1/srvProduct/internal/handler"
	"myshop1/srvProduct/internal/interceptor"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

var confPath string

func init() {
	flag.StringVar(&confPath, "config", "configs/config.yaml", "config file")
}

func main() {
	flag.Parse()
	cfg, err := config.Load(confPath)
	if err != nil {
		log.Fatalf("Failed to load config: %v", err)
	}
	if cfg == nil {
		log.Fatal("Config is nil - check if config file exists: " + confPath)
	}

	logCfg, err := logger.LoadConfig(confPath)
	if err != nil {
		log.Fatalf("Failed to load log config: %v", err)
	}
	l, err := logger.NewLogger(logCfg)
	if err != nil {
		log.Fatalf("Failed to create logger: %v", err)
	}
	defer l.Sync()

	logger.Business.Infow("SRV service starting", "host", cfg.Server.Host, "port", cfg.Server.Port)

	db, err := database.NewDB(&cfg.Database)
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	if db == nil {
		log.Fatal("Database connection is nil - check database config")
	}
	addr := fmt.Sprintf("%s:%d", cfg.Server.Host, cfg.Server.Port)
	lis, err := net.Listen("tcp", addr)
	if err != nil {
		log.Fatalf("Failed to listen on %s: %v", addr, err)
	}
	opts := []grpc.ServerOption{
		grpc.UnaryInterceptor(interceptor.UnaryInterceptor),
	}
	s := grpc.NewServer(opts...)
	storeProduct.RegisterStoreProductServiceServer(s, handler.NewStoreProductHandler(db))
	reflection.Register(s)

	logger.Business.Infow("SRV listening", "addr", addr)

	s.Serve(lis)
}
