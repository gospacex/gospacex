package test

import (
	"context"
	"net"
	"testing"

	"myshop1/common/kitex_gen/eb_store_product"
	"myshop1/pkg/config"
	"myshop1/pkg/database"
	"myshop1/srvProduct/internal/handler"
	"myshop1/srvProduct/internal/service"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

var (
	testSrvAddr = "localhost:8001"
	testClient  StoreProduct.StoreProductServiceClient
	testConn    *grpc.ClientConn
)

func setupGRPCClient(t *testing.T) {
	var err error
	testConn, err = grpc.Dial(testSrvAddr,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
		grpc.WithBlock())
	if err != nil {
		t.Skipf("skipping: cannot connect to gRPC server at %s: %v", testSrvAddr, err)
	}
	testClient = StoreProduct.NewStoreProductServiceClient(testConn)
}

func teardownGRPCClient() {
	if testConn != nil {
		testConn.Close()
	}
}

func startTestServer(t *testing.T) func() {
	cfg, err := config.Load("configs/config.yaml")
	if err != nil {
		t.Skipf("skipping: cannot load config: %v", err)
	}
	db, err := database.NewDB(&cfg.Database)
	if err != nil {
		t.Skipf("skipping: cannot connect to database: %v", err)
	}

	lis, err := net.Listen("tcp", testSrvAddr)
	if err != nil {
		t.Skipf("skipping: cannot listen on %s: %v", testSrvAddr, err)
	}

	srv := grpc.NewServer()
	storeProductHandler := handler.NewStoreProductHandler(db)
	StoreProduct.RegisterStoreProductServiceServer(srv, storeProductHandler)
	go srv.Serve(lis)

	return func() {
		srv.Stop()
		lis.Close()
	}
}

func TestMain(m *testing.M) {
	m.Run()
}

// TestStoreProductService_Create 测试创建
func TestStoreProductService_Create(t *testing.T) {
	setupGRPCClient(t)
	defer teardownGRPCClient()

	resp, err := testClient.Create(context.Background(), &StoreProduct.CreateStoreProductReq{
		StoreName: "Test StoreProduct",
		Price:     99.9,
	})
	if err != nil {
		t.Fatalf("Create failed: %v", err)
	}
	if resp.Id == 0 {
		t.Error("Expected non-zero id")
	}
	t.Logf("Created storeProduct with id: %d", resp.Id)
}

// TestStoreProductService_List 测试列表
func TestStoreProductService_List(t *testing.T) {
	setupGRPCClient(t)
	defer teardownGRPCClient()

	resp, err := testClient.List(context.Background(), &StoreProduct.ListStoreProductReq{})
	if err != nil {
		t.Fatalf("List failed: %v", err)
	}
	t.Logf("Listed %d storeProducts", len(resp.Items))
}

// TestStoreProductService_Get 测试查询
func TestStoreProductService_Get(t *testing.T) {
	setupGRPCClient(t)
	defer teardownGRPCClient()

	createResp, err := testClient.Create(context.Background(), &StoreProduct.CreateStoreProductReq{
		StoreName: "Get Test StoreProduct",
	})
	if err != nil {
		t.Fatalf("Create failed: %v", err)
	}

	resp, err := testClient.Get(context.Background(), &StoreProduct.GetStoreProductReq{
		Id: createResp.Id,
	})
	if err != nil {
		t.Fatalf("Get failed: %v", err)
	}
	if resp.StoreName != "Get Test StoreProduct" {
		t.Errorf("Expected store_name 'Get Test StoreProduct', got '%s'", resp.StoreName)
	}
}

// TestStoreProductService_Update 测试更新
func TestStoreProductService_Update(t *testing.T) {
	setupGRPCClient(t)
	defer teardownGRPCClient()

	createResp, err := testClient.Create(context.Background(), &StoreProduct.CreateStoreProductReq{
		StoreName: "Before Update",
	})
	if err != nil {
		t.Fatalf("Create failed: %v", err)
	}

	_, err = testClient.Update(context.Background(), &StoreProduct.UpdateStoreProductReq{
		Id:        createResp.Id,
		StoreName: "After Update",
	})
	if err != nil {
		t.Fatalf("Update failed: %v", err)
	}

	getResp, err := testClient.Get(context.Background(), &StoreProduct.GetStoreProductReq{
		Id: createResp.Id,
	})
	if err != nil {
		t.Fatalf("Get after update failed: %v", err)
	}
	if getResp.StoreName != "After Update" {
		t.Errorf("Expected store_name 'After Update', got '%s'", getResp.StoreName)
	}
}

// TestStoreProductService_Delete 测试删除
func TestStoreProductService_Delete(t *testing.T) {
	setupGRPCClient(t)
	defer teardownGRPCClient()

	createResp, err := testClient.Create(context.Background(), &StoreProduct.CreateStoreProductReq{
		StoreName: "To Delete",
	})
	if err != nil {
		t.Fatalf("Create failed: %v", err)
	}

	_, err = testClient.Delete(context.Background(), &StoreProduct.DeleteStoreProductReq{
		Id: createResp.Id,
	})
	if err != nil {
		t.Fatalf("Delete failed: %v", err)
	}

	_, err = testClient.Get(context.Background(), &StoreProduct.GetStoreProductReq{
		Id: createResp.Id,
	})
	if err == nil {
		t.Error("Expected error when getting deleted storeProduct, got nil")
	}
}