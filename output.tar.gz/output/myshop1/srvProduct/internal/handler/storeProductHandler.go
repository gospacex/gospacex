package handler

import (
	"context"
	"time"

	pb "myshop1/common/kitexGen/storeProduct"
	"myshop1/pkg/logger"
	"myshop1/pkg/utils"
	"myshop1/srvProduct/internal/model"
	"myshop1/srvProduct/internal/repository"
	"myshop1/srvProduct/internal/service"

	"github.com/jinzhu/copier"

	"gorm.io/gorm"
)

type StoreProductHandler struct {
	pb.UnimplementedStoreProductServiceServer
	svc *service.StoreProductService
}

func NewStoreProductHandler(db *gorm.DB) *StoreProductHandler {
	logger.Business.Infow("StoreProductHandler initializing")
	return &StoreProductHandler{
		svc: service.NewStoreProductService(
			repository.NewStoreProductRepo(db),
		),
	}
}

func (h *StoreProductHandler) Create(ctx context.Context, req *pb.CreateStoreProductReq) (*pb.CreateStoreProductResp, error) {
	start := time.Now()
	logger.Business.Infow("handle create product")

	m := &model.StoreProduct{}
	if err := copier.Copy(m, req); err != nil {
		logger.Business.Errorw("copy request to model failed", "error", err.Error())
		return nil, err
	}

	if err := h.svc.Create(ctx, m); err != nil {
		logger.Business.Errorw("create product failed", "error", err.Error())
		return nil, err
	}

	logger.Business.Infow("create product success", "id", m.Id, "duration", time.Since(start).String())
	return &pb.CreateStoreProductResp{Id: int64(m.Id)}, nil
}

func (h *StoreProductHandler) Get(ctx context.Context, req *pb.GetStoreProductReq) (*pb.GetStoreProductResp, error) {
	start := time.Now()
	logger.Business.Infow("handle get product", "id", req.Id)

	m, err := h.svc.Get(ctx, int64(req.Id))
	if err != nil {
		logger.Business.Errorw("get product failed", "error", err.Error())
		return nil, err
	}

	logger.Business.Infow("get product success", "id", m.Id, "duration", time.Since(start).String())
	resp := &pb.GetStoreProductResp{}
	copier.Copy(resp, m)
	return resp, nil
}

func (h *StoreProductHandler) List(ctx context.Context, req *pb.ListStoreProductReq) (*pb.ListStoreProductResp, error) {
	start := time.Now()
	logger.Business.Infow("handle list product")

	list, err := h.svc.ListWithFilter(ctx, req)
	if err != nil {
		logger.Business.Errorw("list product failed", "error", err.Error())
		return nil, err
	}

	var items []*pb.StoreProductItem
	for _, m := range list {
		item := &pb.StoreProductItem{}
		copier.Copy(item, m)
		items = append(items, item)
	}

	logger.Business.Infow("list product success", "count", len(list), "duration", time.Since(start).String())
	return &pb.ListStoreProductResp{Items: items}, nil
}

func (h *StoreProductHandler) Update(ctx context.Context, req *pb.UpdateStoreProductReq) (*pb.UpdateStoreProductResp, error) {
	start := time.Now()
	logger.Business.Infow("handle update product", "id", req.Id)

	m, err := h.svc.Get(ctx, int64(req.Id))
	if err != nil {
		logger.Business.Errorw("get product for update failed", "error", err.Error())
		return nil, err
	}

	if err := utils.PartialUpdate(m, req); err != nil {
		logger.Business.Errorw("partial update failed", "error", err.Error())
		return nil, err
	}

	if err := h.svc.Update(ctx, m); err != nil {
		logger.Business.Errorw("update product failed", "error", err.Error())
		return nil, err
	}

	logger.Business.Infow("update product success", "id", req.Id, "duration", time.Since(start).String())
	return &pb.UpdateStoreProductResp{Success: true}, nil
}

func (h *StoreProductHandler) Delete(ctx context.Context, req *pb.DeleteStoreProductReq) (*pb.DeleteStoreProductResp, error) {
	start := time.Now()
	logger.Business.Infow("handle delete product", "id", req.Id)

	if err := h.svc.Delete(ctx, int64(req.Id)); err != nil {
		logger.Business.Errorw("delete product failed", "error", err.Error())
		return nil, err
	}

	logger.Business.Infow("delete product success", "id", req.Id, "duration", time.Since(start).String())
	return &pb.DeleteStoreProductResp{Success: true}, nil
}

func (h *StoreProductHandler) FindJoinProduct2ProductAttr(ctx context.Context, req *pb.GetStoreProduct2ProductAttrReq) (*pb.GetStoreProduct2ProductAttrResp, error) {
	start := time.Now()
	logger.Business.Infow("handle find join store product 2 store product attr", "filter", req)
	var resp pb.GetStoreProduct2ProductAttrResp
	m, err := h.svc.JoinGetStoreProductStoreProductAttr(ctx, int64(req.Id))
	if err != nil {
		logger.Business.Errorw("find join store product 2 store product attr failed", "error", err.Error())
		return nil, err
	}
	copier.Copy(&resp, m)
	logger.Business.Infow("find join store product 2 store product attr success", "duration", time.Since(start).String())
	return &resp, nil
}
